# bashrail

https://github.com/dgleba/bashrail

===

This is a set of bash and ruby scripts to create a rails app with features like bootstrap, select2, devise, cancan, etc...


 usage:

      bashrail/1mk.sh  project_name

 where project_name is the name you want to give your new rails app..

 example..
 - input..  /var/web/bashrail
 - output.. /var/web/project_name
 - run command above from /var/web

--


 edit 1mk.sh
  - There are some Mac OSX specific settings around line 77. Check that.
  - Check to see if you might just run it the way it is and give it a go.
  - when it is up and running, then maybe...
  - edit scaffolds.
  - try it out.
  - change the files to your liking, then run it again with a new $appn / project_name on the commandline if you like.


===

### Notes..




ref..
    Rail308

===


